﻿using System;

namespace GenericArrayCreator
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            string[] array = GenericArrayCreator.Create(5, "Pesho");
            Console.WriteLine(string.Join(",",array));
        }
    }
}
