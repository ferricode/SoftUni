﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace _01.Library
{
    public class Library<T> : IEnumerable<T> where T:Book
    {
        private readonly List<T> books;
        public Library(IEnumerable<T> books)
        {
            this.books = new List<T>(books);
        }
        public Library()
        {
            books = new List<T>();
        }
        public IEnumerator<T> GetEnumerator()
        {
            foreach (var book in books)
            {
                yield return book;
            }
            //02.return new LibraryIterator<T>(books);
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return this.GetEnumerator();
        }

    }
}
