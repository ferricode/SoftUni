﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Shapes
{
    interface IDrowable
    {
        public void Drow();


    }
}
