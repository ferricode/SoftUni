﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MilitaryElite.Enumerations
{
    public enum MissionStateEnum
    {
        inProgress = 1,
        Finished = 2,

    }
}
