﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Telephony
{
    public interface ICallable
    {

        void Call(string number);
    }
}
