﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Easter.Repositories
{
    class BunnyRepository
    {
    }
}
