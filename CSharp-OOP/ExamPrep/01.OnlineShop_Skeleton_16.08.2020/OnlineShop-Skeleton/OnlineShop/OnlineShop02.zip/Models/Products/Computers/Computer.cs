﻿using OnlineShop.Models.Products.Components;
using OnlineShop.Models.Products.Peripherals;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OnlineShop.Models.Products.Computers
{
    public abstract class Computer : Product, IComputer
    {
        private readonly List<IComponent> components;
        private readonly List<IPeripheral> peripherals;
        private decimal priceC;
        private double overallPerformanceC;
        protected Computer(int id, string manufacturer, string model, decimal price, double overallPerformance)
            : base(id, manufacturer, model, price, overallPerformance)
        {

            overallPerformance = OverallPerformance;
            price = Price;


            //if this is correct?!
        }

        public override double OverallPerformance => CalculateOverallPerformance();
        public override decimal Price => priceC + components.Sum(c => c.Price) + peripherals.Sum(p => p.Price);

        private double CalculateOverallPerformance()
        {
            if (components.Count == 0)
            {
                return overallPerformanceC;

            }
            var averageComponentsPerformance = components.Average(c => c.OverallPerformance);
            return overallPerformanceC + averageComponentsPerformance;
        }

        public IReadOnlyCollection<IComponent> Components => components.ToList();

        public IReadOnlyCollection<IPeripheral> Peripherals => peripherals.ToList();

        public void AddComponent(IComponent component)
        {

            if (components.Any(c => c.GetType().Name == component.GetType().Name))
            {
                throw new ArgumentException($"Component {component.GetType().Name} already exists in {GetType().Name} with Id {Id}.");
            }
            components.Add(component);
        }

        public void AddPeripheral(IPeripheral peripheral)
        {
            if (peripherals.Any(p => p.GetType().Name == peripheral.GetType().Name))
            {
                throw new ArgumentException($"Peripheral {peripheral.GetType().Name } already exists in {GetType().Name} with Id {Id}.");
            }
            peripherals.Add(peripheral);
        }

        public IComponent RemoveComponent(string componentType)
        {
            if (components.Count == 0|| !components.Any(c => c.GetType().Name == componentType))
            {
                throw new ArgumentException($"Component {componentType} does not exist in {GetType().Name} with Id {Id}.");
            }
            var componentToRemove = components.FirstOrDefault(c => c.GetType().Name == componentType);
            
            components.Remove(componentToRemove);
            return componentToRemove;
        }

        public IPeripheral RemovePeripheral(string peripheralType)
        {
            if (peripherals.Count == 0 || !peripherals.Any(c => c.GetType().Name == peripheralType))
            {
                throw new ArgumentException($"Peripheral {peripheralType} does not exist in {GetType().Name} with Id {Id}.");
            }
            var peripheralToRemove = peripherals.FirstOrDefault(c => c.GetType().Name == peripheralType);

            peripherals.Remove(peripheralToRemove);
            return peripheralToRemove;
        }
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"Overall Performance: {OverallPerformance}. Price: {Price} - {GetType().Name}: {Manufacturer} {Model} (Id: {Id})");
            sb.AppendLine($" Components ({Components.Count}):");
            foreach (var item in components)
            {
                sb.AppendLine($" {item.GetType().Name}");
            }
            sb.AppendLine($" Peripherals ({peripherals.Count}); Average Overall Performance ({peripherals.Average(p => p.OverallPerformance)}):");
            foreach (var item in peripherals)
            {
                sb.AppendLine($"  {item.GetType().Name}");
            }

            return sb.ToString().TrimEnd();
        }
    }
}
