﻿namespace PersonsInfo
{
    internal class list<T>
    {
    }
}